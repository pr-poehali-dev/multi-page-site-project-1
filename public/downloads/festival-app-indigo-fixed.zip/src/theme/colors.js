// Цветовая схема "Индиго-Арт"
export const COLORS = {
  primary: '#4B0082',
  primaryDark: '#311B92',
  primaryLight: '#7C4DFF',
  pale: '#EDE7F6',
  tagBg: '#E1BEE7',
  tagText: '#4A148C',
  text: '#5E35B1',
  border: '#D1C4E9',
  white: '#FFFFFF',
  background: '#FAF8FF',
  cardBg: '#FFFFFF',
  success: '#4CAF50',
  warning: '#FF9800',
  danger: '#F44336',
  placeholder: '#B39DDB',
  navInactive: '#B39DDB',
};
