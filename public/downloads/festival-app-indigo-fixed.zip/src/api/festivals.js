import { API_URLS, YANDEX_DISK_TOKEN } from '../config/api';
import { apiRequest } from './client';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { readAsStringAsync } from 'expo-file-system';

// Token imported from config/api.js
const YA_API = 'https://cloud-api.yandex.net/v1/disk';

// ==================== КОНКУРСЫ ====================

export async function fetchFestivals() {
  try {
    console.log('🎭 Trying fetch contests WITHOUT api key...');
    const data = await apiRequest(API_URLS.contests, { method: 'GET' }, false, false);
    const result = sortContestsByDate(parseContestsResponse(data));
    if (result.length > 0) {
      console.log('✅ Contests loaded (no key):', result.length);
      return result;
    }
    console.log('⚠️ No contests without key, trying WITH key...');
  } catch (err) {
    console.log('⚠️ Failed without key:', err.message);
  }

  try {
    const data = await apiRequest(API_URLS.contests, { method: 'GET' }, false, true);
    const result = sortContestsByDate(parseContestsResponse(data));
    console.log('✅ Contests loaded (with key):', result.length);
    return result;
  } catch (err) {
    console.error('❌ Failed with key too:', err.message);
    throw err;
  }
}

function parseContestsResponse(data) {
  if (!data) return [];
  if (Array.isArray(data)) return data;
  const possibleFields = ['data', 'results', 'contests', 'items', 'list', 'records', 'entries', 'body', 'response'];
  for (const field of possibleFields) {
    if (data[field] && Array.isArray(data[field])) return data[field];
  }
  if (data.data && typeof data.data === 'object') {
    for (const field of possibleFields) {
      if (data.data[field] && Array.isArray(data.data[field])) return data.data[field];
    }
  }
  return [];
}

function sortContestsByDate(list) {
  const dateFields = ['event_date', 'date', 'start_date', 'begin_date', 'eventDate', 'startDate', 'date_start'];
  const getDate = (item) => {
    for (const field of dateFields) {
      const raw = item[field];
      if (raw) {
        const parsed = new Date(raw);
        if (!isNaN(parsed.getTime())) return parsed.getTime();
      }
    }
    return Infinity;
  };
  return [...list].sort((a, b) => getDate(a) - getDate(b));
}

export async function fetchFestivalDetail(id) {
  const list = await fetchFestivals();
  return list.find(item => (item.id || item._id) === id) || null;
}

// ==================== ФОРМА ЗАЯВКИ ====================

export async function fetchContestForm(contestId) {
  const url = `${API_URLS.contests}?action=contest_form&contest_id=${contestId}`;
  return apiRequest(url, { method: 'GET' }, false, false);
}

// ==================== ЗАЯВКИ ====================

export async function submitApplication(festivalId, data) {
  return apiRequest(
    API_URLS.applications,
    {
      method: 'POST',
      body: JSON.stringify({
        contest_id: festivalId,
        name: data.name,
        email: data.email,
        phone: data.phone,
        description: data.description,
      }),
    },
    true,
    false
  );
}

export async function fetchMyApplications() {
  const participantId = await AsyncStorage.getItem('participantId');
  console.log('📧 fetchMyApplications: participantId:', participantId);
  if (!participantId) {
    throw new Error('ID участника не найден. Выйдите и войдите снова.');
  }

  const url = `${API_URLS.auth}?action=applications&participant_id=${encodeURIComponent(participantId)}`;
  console.log('🌐 fetchMyApplications: URL:', url);
  const data = await apiRequest(url, { method: 'GET' }, true, false);
  console.log('📥 fetchMyApplications: raw response:', JSON.stringify(data).substring(0, 800));

  // Парсим ответ
  const apps = data.applications || data.data || data.results || data.items || data;
  if (Array.isArray(apps)) {
    console.log('✅ fetchMyApplications: found', apps.length, 'applications');
    return apps;
  }
  if (apps && typeof apps === 'object' && !Array.isArray(apps)) {
    if (apps.contestId || apps.id || apps._id || apps.applicationId) {
      console.log('✅ fetchMyApplications: single application object');
      return [apps];
    }
  }
  console.log('⚠️ fetchMyApplications: no applications found');
  return [];
}

// ==================== АВТОРИЗАЦИЯ ====================

export async function loginUser(credentials) {
  return apiRequest(API_URLS.auth, { method: 'POST', body: JSON.stringify(credentials) }, false, false);
}

export async function registerUser(data) {
  return apiRequest(API_URLS.auth, { method: 'POST', body: JSON.stringify(data) }, false, false);
}

export async function fetchMe() {
  return apiRequest(API_URLS.auth, { method: 'GET' }, true, false);
}

// ==================== ВНУТРЕННИЕ ЗАЯВКИ ====================

export async function submitInternalApplication(data) {
  return apiRequest(
    API_URLS.applications,
    { method: 'POST', body: JSON.stringify(data) },
    true,
    false
  );
}

// ==================== ЯНДЕКС.ДИСК ====================

function base64ToUint8Array(base64) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function uploadToYandexDisk(file, contestTitle) {
  // contestTitle формируется как: "Название, Город, Дата" (без лишних запятых)
  console.log('📋 Uploading to Yandex via server. contestTitle:', contestTitle);

  // 1. Получаем ссылку для загрузки от сервера
  console.log('🌐 Step 1: Getting upload URL from server...');
  const step1 = await apiRequest(
    API_URLS.fileUpload,
    {
      method: 'POST',
      body: JSON.stringify({
        target: 'yandex',
        contestTitle: contestTitle,
        fileName: file.name,
      }),
    },
    true,  // needsAuth
    false
  );
  console.log('📥 Step 1 response:', JSON.stringify(step1, null, 2));

  const href = step1.uploadUrl || step1.href || step1.upload_url || step1.url;
  const uploadPath = step1.path;

  if (!href) {
    throw new Error('Сервер не вернул ссылку для загрузки. Ответ: ' + JSON.stringify(step1));
  }

  // 2. Загружаем файл напрямую на Яндекс.Диск
  console.log('☁️ Step 2: PUT file to Yandex Disk...');
  const base64 = await readAsStringAsync(file.uri, { encoding: 'base64' });
  const body = base64ToUint8Array(base64);
  console.log('☁️ Uploading', body.length, 'bytes...');

  const uploadRes = await fetch(href, {
    method: 'PUT',
    headers: { 'Content-Type': file.mimeType || 'application/octet-stream' },
    body,
  });

  console.log('📥 Yandex upload status:', uploadRes.status);
  if (!uploadRes.ok) {
    const text = await uploadRes.text();
    throw new Error(`Yandex upload failed: ${uploadRes.status} ${text}`);
  }
  console.log('☁️ File uploaded to Yandex OK');

  // 3. Финализируем — публикуем файл через сервер
  console.log('🌐 Step 3: Finalizing via server...');
  const step3 = await apiRequest(
    API_URLS.fileUpload,
    {
      method: 'POST',
      body: JSON.stringify({
        target: 'yandex',
        step: 'finalize',
        path: uploadPath,
      }),
    },
    true,
    false
  );
  console.log('📥 Step 3 response:', JSON.stringify(step3, null, 2));

  const publicUrl = step3.public_url || step3.url || step3.fileUrl || step3.link;
  if (!publicUrl) {
    throw new Error('Сервер не вернул public_url после публикации. Ответ: ' + JSON.stringify(step3));
  }

  console.log('✅ Public URL:', publicUrl);
  return publicUrl;
}