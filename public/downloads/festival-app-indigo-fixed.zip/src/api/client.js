import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_URLS, API_KEY, API_KEY_HEADER, AUTH_HEADER } from '../config/api';

export async function apiRequest(url, options = {}, needsAuth = false, needsApiKey = false) {
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    ...options.headers,
  };

  if (needsApiKey) {
    headers[API_KEY_HEADER] = API_KEY;
  }

  if (needsAuth) {
    const token = await AsyncStorage.getItem('userToken');
    if (token) {
      headers[AUTH_HEADER] = `Bearer ${token}`;
    }
  }

  console.log('🌐 API Request:', url);
  console.log('📤 Headers:', JSON.stringify(headers, null, 2));
  if (options.body) {
    console.log('📦 Body:', options.body);
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  console.log('📥 Response status:', response.status);

  const text = await response.text();
  console.log('📥 Response body (raw):', text.substring(0, 500));

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${text}`);
  }

  try {
    return JSON.parse(text);
  } catch (e) {
    console.error('❌ Failed to parse JSON:', e.message);
    throw new Error('Invalid JSON response');
  }
}
