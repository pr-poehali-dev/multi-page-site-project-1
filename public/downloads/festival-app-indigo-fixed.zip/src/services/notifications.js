import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { useEffect, useRef } from 'react';
import { fetchFestivalDetail } from '../api/festivals';

// projectId из app.json / eas.json
const PROJECT_ID = '68d6940c-8752-4599-814e-639bb87817d3';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export async function registerForPushNotifications(sessionToken) {
  console.log('🔔 registerForPushNotifications called, token exists:', !!sessionToken);

  if (!Device.isDevice) {
    console.log('Push-уведомления работают только на реальном устройстве');
    return null;
  }

  // Android: создаём канал уведомлений (нужен для Android 8+)
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#4B0082',
    });
    console.log('🔔 Android notification channel created');
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  console.log('🔔 Existing permission status:', existingStatus);

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
    console.log('🔔 Permission requested, new status:', status);
  }

  if (finalStatus !== 'granted') {
    console.log('❌ Пользователь не дал разрешение на уведомления');
    return null;
  }

  try {
    console.log('🔔 Getting Expo push token with projectId:', PROJECT_ID);
    const { data: pushToken } = await Notifications.getExpoPushTokenAsync({
      projectId: PROJECT_ID,
    });

    console.log('📲 Push token received:', pushToken);

    if (!pushToken) {
      console.error('❌ Push token is empty!');
      return null;
    }

    // === СОХРАНЯЕМ ТОКЕН НА СЕРВЕРЕ ===
    const url = 'https://functions.poehali.dev/52234468-777f-4edf-ba7a-985257092904?action=save_push_token';
    const body = JSON.stringify({ pushToken });
    const headers = {
      'Content-Type': 'application/json',
      // 'Authorization' обрезается облачным провайдером на пути к серверу —
      // сервер читает токен участника из 'X-Authorization'
      'X-Authorization': `Bearer ${sessionToken}`,
    };

    console.log('📤 Sending push token to server...');
    console.log('   URL:', url);
    console.log('   Headers:', JSON.stringify(headers));
    console.log('   Body:', body);

    const res = await fetch(url, { method: 'POST', headers, body });

    const resText = await res.text();
    let resData;
    try {
      resData = JSON.parse(resText);
    } catch {
      resData = { raw: resText };
    }

    console.log('📤 Server response status:', res.status);
    console.log('📤 Server response body:', JSON.stringify(resData));

    if (!res.ok) {
      console.error('❌ Server rejected push token. Status:', res.status, 'Body:', resData);
    } else {
      console.log('✅ Push token saved successfully');
    }

    return pushToken;
  } catch (err) {
    console.error('❌ Failed to get or save push token:', err.message);
    console.error('   Stack:', err.stack);
    return null;
  }
}

// navigationRef — это ref на <NavigationContainer>, а не сам объект navigation экрана,
// поэтому переход делается через navigationRef.current.navigate(...) и с указанием
// вложенного таб-экрана + экрана внутри его стека (структура заведена в App.js).
async function handleNotificationNavigation(navigationRef, data) {
  if (!data || !navigationRef?.current) return;

  // Дожидаемся, пока NavigationContainer будет готов принимать команды навигации —
  // важно, когда пользователь открывает приложение нажатием на уведомление "холодным" стартом.
  if (!navigationRef.current.isReady()) {
    await new Promise(resolve => {
      const check = setInterval(() => {
        if (navigationRef.current?.isReady()) {
          clearInterval(check);
          resolve();
        }
      }, 100);
    });
  }

  switch (data.screen) {
    case 'MyApplications':
      navigationRef.current.navigate('ЗаявкиTab', { screen: 'ApplicationsList' });
      break;
    case 'FestivalDetail': {
      if (!data.contestId) break;
      try {
        const festival = await fetchFestivalDetail(data.contestId);
        if (festival) {
          navigationRef.current.navigate('ФестивалиTab', {
            screen: 'FestivalDetail',
            params: { festival },
          });
        }
      } catch (err) {
        console.log('⚠️ Не удалось открыть конкурс из уведомления:', err.message);
      }
      break;
    }
    default:
      break;
  }
}

export function usePushNotificationsListener(navigationRef) {
  const responseListener = useRef();

  useEffect(() => {
    responseListener.current = Notifications.addNotificationResponseReceivedListener(response => {
      const data = response.notification.request.content.data;
      console.log('👆 Notification tapped:', data);
      handleNotificationNavigation(navigationRef, data);
    });

    Notifications.getLastNotificationResponseAsync().then(response => {
      if (response) {
        const data = response.notification.request.content.data;
        console.log('🚀 App launched from notification:', data);
        handleNotificationNavigation(navigationRef, data);
      }
    });

    return () => {
      Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, [navigationRef]);
}
