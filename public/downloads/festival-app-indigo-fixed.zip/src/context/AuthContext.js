import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { loginUser, registerUser, fetchMe } from '../api/festivals';
import { registerForPushNotifications } from '../services/notifications';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { checkAuth(); }, []);

  const checkAuth = async () => {
    try {
      console.log('🔐 checkAuth: reading token...');
      const token = await AsyncStorage.getItem('userToken');
      console.log('🔐 Token exists:', !!token);
      if (token) {
        try {
          const data = await fetchMe();
          console.log('🔐 fetchMe success:', JSON.stringify(data).substring(0, 200));
          const participant = data.participant || data.user || data;
          const email = participant.email || data.email || '';
          const participantId = participant.id || participant._id;
          if (email) await AsyncStorage.setItem('userEmail', email);
          if (participantId) await AsyncStorage.setItem('participantId', String(participantId));
          setUser({ ...participant, token });
          console.log('🔐 User restored from token');
        } catch (meErr) {
          console.log('⚠️ fetchMe failed:', meErr.message, '- keeping token, setting user from storage');
          const savedEmail = await AsyncStorage.getItem('userEmail');
          setUser({ email: savedEmail, token });
        }
      } else {
        console.log('🔐 No token found');
      }
    } catch (e) {
      console.error('❌ checkAuth error:', e.message);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    console.log('🔐 Login attempt:', email);
    const data = await loginUser({ email, password });
    const token = data.token || data.access_token || '';
    const participant = data.participant || data.user || {};
    const participantId = participant.id || participant._id;
    const userEmail = participant.email || email;

    await AsyncStorage.setItem('userToken', token);
    await AsyncStorage.setItem('userEmail', userEmail);
    if (participantId) await AsyncStorage.setItem('participantId', String(participantId));

    setUser({ ...participant, token });
    console.log('🔐 Login success, user set');

    // Регистрируем push token после входа
    try {
      console.log('🔔 Calling registerForPushNotifications after login...');
      const pushResult = await registerForPushNotifications(token);
      console.log('🔔 Push registration result:', pushResult ? 'success' : 'failed/null');
    } catch (pushErr) {
      console.log('⚠️ Push registration failed:', pushErr.message);
    }
  };

  const register = async (name, email, password) => {
    console.log('🔐 Register attempt:', email);
    const data = await registerUser({ name, email, password });
    const token = data.token || data.access_token || '';
    const participant = data.participant || data.user || {};
    const participantId = participant.id || participant._id;
    const userEmail = participant.email || email;

    await AsyncStorage.setItem('userToken', token);
    await AsyncStorage.setItem('userEmail', userEmail);
    if (participantId) await AsyncStorage.setItem('participantId', String(participantId));

    setUser({ ...participant, token });
    console.log('🔐 Register success, user set');

    // Регистрируем push token после регистрации
    try {
      console.log('🔔 Calling registerForPushNotifications after register...');
      const pushResult = await registerForPushNotifications(token);
      console.log('🔔 Push registration result:', pushResult ? 'success' : 'failed/null');
    } catch (pushErr) {
      console.log('⚠️ Push registration failed:', pushErr.message);
    }
  };

  const logout = async () => {
    console.log('🔐 Logout');
    await AsyncStorage.removeItem('userToken');
    await AsyncStorage.removeItem('userEmail');
    await AsyncStorage.removeItem('participantId');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
