import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, FlatList, RefreshControl, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { fetchNotifications, markNotificationRead } from '../api/festivals';
import { COLORS } from '../theme/colors';

function formatDate(raw) {
  if (!raw) return '';
  try {
    const d = new Date(raw);
    return d.toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
  } catch {
    return String(raw);
  }
}

function NotificationCard({ item, onPress }) {
  return (
    <TouchableOpacity style={[styles.card, !item.is_read && styles.cardUnread]} onPress={() => onPress(item)}>
      <View style={styles.cardHeader}>
        {!item.is_read ? <View style={styles.dot} /> : null}
        <Text style={styles.cardTitle}>{item.title}</Text>
      </View>
      <Text style={styles.cardBody}>{item.body}</Text>
      <Text style={styles.cardDate}>{formatDate(item.created_at)}</Text>
    </TouchableOpacity>
  );
}

export default function NotificationsScreen() {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      setError(null);
      const list = await fetchNotifications();
      setItems(list);
    } catch (e) {
      setError(e.message || 'Не удалось загрузить уведомления');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  const onPressItem = async (item) => {
    if (item.is_read) return;
    setItems(prev => prev.map(n => (n.id === item.id ? { ...n, is_read: true } : n)));
    try {
      await markNotificationRead(item.id);
    } catch (e) {
      // не критично, просто не пометилось на сервере
    }
  };

  if (!user) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.emptyTitle}>Войдите в аккаунт</Text>
        <Text style={styles.emptyText}>Чтобы видеть свои уведомления</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Загрузка уведомлений...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.emptyTitle}>Ошибка</Text>
        <Text style={styles.emptyText}>{error}</Text>
        <TouchableOpacity style={styles.btnPrimary} onPress={load}>
          <Text style={styles.btnPrimaryText}>Повторить</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Уведомления</Text>
      <FlatList
        data={items}
        keyExtractor={item => String(item.id)}
        renderItem={({ item }) => <NotificationCard item={item} onPress={onPressItem} />}
        contentContainerStyle={items.length === 0 ? styles.emptyList : styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[COLORS.primary]} />}
        ListEmptyComponent={
          <View style={styles.center}>
            <Text style={styles.emptyTitle}>Пока нет уведомлений</Text>
            <Text style={styles.emptyText}>Здесь будут появляться новости о конкурсах и статусе ваших заявок</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, paddingHorizontal: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 20, paddingTop: 60 },
  header: { fontSize: 28, fontWeight: '500', marginBottom: 16, marginTop: 8, color: COLORS.primary },
  list: { paddingBottom: 24 },
  emptyList: { flexGrow: 1 },
  card: {
    backgroundColor: COLORS.cardBg,
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  cardUnread: { borderColor: COLORS.primaryLight, backgroundColor: COLORS.pale },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.primaryLight, marginRight: 8 },
  cardTitle: { fontSize: 16, fontWeight: '600', color: COLORS.primary, flexShrink: 1 },
  cardBody: { fontSize: 14, color: COLORS.text, marginTop: 4, lineHeight: 20 },
  cardDate: { fontSize: 12, color: COLORS.placeholder, marginTop: 8 },
  loadingText: { marginTop: 16, fontSize: 15, color: COLORS.text },
  emptyTitle: { fontSize: 18, fontWeight: '500', marginBottom: 6, color: COLORS.primary, textAlign: 'center' },
  emptyText: { fontSize: 15, color: COLORS.text, marginBottom: 12, textAlign: 'center' },
  btnPrimary: { backgroundColor: COLORS.primary, paddingHorizontal: 32, paddingVertical: 14, borderRadius: 12, marginTop: 8 },
  btnPrimaryText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
