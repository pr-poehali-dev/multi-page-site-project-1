import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, RefreshControl, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { fetchMyApplications } from '../api/festivals';
import { COLORS } from '../theme/colors';

function ApplicationCard({ item }) {
  const statusLabels = {
    pending: { text: 'На рассмотрении', color: '#FF9800' },
    approved: { text: 'Одобрена', color: '#4CAF50' },
    rejected: { text: 'Отклонена', color: '#F44336' },
  };
  const status = statusLabels[item.status] || { text: item.status || '—', color: '#999' };
  const isEditable = item.is_editable !== false;

  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>{item.contest_title || item.contestTitle || 'Конкурс'}</Text>
      {item.nomination ? <Text style={styles.cardNomination}>🎭 {item.nomination}</Text> : null}
      <View style={styles.cardRow}>
        <View style={[styles.badge, { backgroundColor: status.color + '20', borderColor: status.color }]}>
          <Text style={[styles.badgeText, { color: status.color }]}>{status.text}</Text>
        </View>
        {isEditable ? <Text style={styles.editable}>✏️ Редактируемая</Text> : null}
      </View>
      <Text style={styles.cardDate}>📅 Подана: {formatDate(item.submitted_at || item.submittedAt || item.created_at)}</Text>
      {item.end_date || item.endDate ? (
        <Text style={styles.cardDeadline}>⏰ Конкурс до: {formatDate(item.end_date || item.endDate)}</Text>
      ) : null}
    </View>
  );
}

function formatDate(raw) {
  if (!raw) return '—';
  try {
    const d = new Date(raw);
    return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
  } catch {
    return String(raw);
  }
}

function isActive(item) {
  const endDate = item.end_date || item.endDate;
  if (!endDate) return true;
  return new Date(endDate) >= new Date();
}

export default function ApplicationsScreen({ navigation }) {
  const { user } = useAuth();
  const [activeApps, setActiveApps] = useState([]);
  const [archivedApps, setArchivedApps] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  // ВСЕ хуки вызываются ДО любого условного return
  const loadApplications = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchMyApplications();
      const active = data.filter(isActive);
      const archived = data.filter(a => !isActive(a));
      setActiveApps(active);
      setArchivedApps(archived);
      console.log('✅ Active:', active.length, '| Archived:', archived.length);
    } catch (err) {
      console.error('❌ Failed to load applications:', err);
      setError(err.message || 'Не удалось загрузить заявки');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (user) {
      loadApplications();
    }
  }, [user]);

  const onRefresh = () => {
    setRefreshing(true);
    if (user) {
      loadApplications();
    }
  };

  // Теперь условный рендеринг — ПОСЛЕ всех хуков
  if (!user) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.emptyTitle}>🔒 Войдите в аккаунт</Text>
        <Text style={styles.emptyText}>
          Чтобы видеть свои заявки, войдите в аккаунт или зарегистрируйтесь
        </Text>
        <TouchableOpacity style={styles.btnPrimary} onPress={() => navigation.navigate('Login')}>
          <Text style={styles.btnPrimaryText}>Войти</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnSecondary} onPress={() => navigation.navigate('Register')}>
          <Text style={styles.btnSecondaryText}>Зарегистрироваться</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (loading && !refreshing) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Загрузка заявок...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={loadApplications}>
          <Text style={styles.retryText}>Повторить</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const totalCount = activeApps.length + archivedApps.length;

  if (totalCount === 0) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.emptyTitle}>Заявок пока нет</Text>
        <Text style={styles.emptyText}>Подайте заявку на конкурс во вкладке «Фестивали»</Text>
        <TouchableOpacity style={styles.btnPrimary} onPress={() => navigation.navigate('FestivalsList')}>
          <Text style={styles.btnPrimaryText}>🎭 К фестивалям</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <FlatList
      style={styles.container}
      contentContainerStyle={styles.content}
      data={[
        { type: 'header', count: totalCount },
        { type: 'active_header' },
        ...activeApps.map(a => ({ type: 'app', item: a })),
        { type: 'archived_header' },
        ...archivedApps.map(a => ({ type: 'app', item: a })),
      ]}
      keyExtractor={(item, index) => `${item.type}_${index}`}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      renderItem={({ item }) => {
        if (item.type === 'header') {
          return (
            <>
              <Text style={styles.header}>Мои заявки</Text>
              <Text style={styles.subHeader}>Всего: {item.count} ({activeApps.length} активных)</Text>
            </>
          );
        }
        if (item.type === 'active_header') {
          if (activeApps.length === 0) return <Text style={styles.sectionEmpty}>Нет активных заявок</Text>;
          return <Text style={styles.sectionTitle}>🟢 Активные</Text>;
        }
        if (item.type === 'archived_header') {
          if (archivedApps.length === 0) return null;
          return <Text style={styles.sectionTitle}>📁 Архив</Text>;
        }
        return <ApplicationCard item={item.item} />;
      }}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: 16, paddingBottom: 32 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  header: { fontSize: 28, fontWeight: '500', marginBottom: 4, color: COLORS.primary },
  subHeader: { fontSize: 14, color: COLORS.text, marginBottom: 20 },
  sectionTitle: { fontSize: 18, fontWeight: '600', color: COLORS.primary, marginTop: 16, marginBottom: 10 },
  sectionEmpty: { fontSize: 14, color: COLORS.placeholder, marginVertical: 10, fontStyle: 'italic' },
  card: { backgroundColor: COLORS.white, borderRadius: 12, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: COLORS.pale },
  cardTitle: { fontSize: 16, fontWeight: '600', color: COLORS.primary, marginBottom: 6 },
  cardNomination: { fontSize: 13, color: COLORS.text, marginBottom: 8 },
  cardRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, borderWidth: 1, marginRight: 8 },
  badgeText: { fontSize: 12, fontWeight: '500' },
  editable: { fontSize: 12, color: COLORS.primary },
  cardDate: { fontSize: 13, color: COLORS.text },
  cardDeadline: { fontSize: 13, color: COLORS.text, marginTop: 2 },
  loadingText: { marginTop: 12, fontSize: 15, color: COLORS.text },
  errorText: { fontSize: 15, color: '#D32F2F', marginBottom: 12, textAlign: 'center' },
  retryBtn: { backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 10 },
  retryText: { color: '#fff', fontSize: 15, fontWeight: '500' },
  emptyTitle: { fontSize: 18, fontWeight: '500', marginBottom: 6, color: COLORS.primary },
  emptyText: { fontSize: 14, color: COLORS.text, marginBottom: 12, textAlign: 'center' },
  btnPrimary: { backgroundColor: COLORS.primary, paddingHorizontal: 32, paddingVertical: 14, borderRadius: 12, marginBottom: 10 },
  btnPrimaryText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  btnSecondary: { backgroundColor: COLORS.white, paddingHorizontal: 32, paddingVertical: 14, borderRadius: 12, borderWidth: 1.5, borderColor: COLORS.border },
  btnSecondaryText: { color: COLORS.primary, fontSize: 16, fontWeight: '500' },
});
