import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { COLORS } from '../theme/colors';

export default function RegisterScreen({ navigation }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();

  const handleRegister = async () => {
    if (!name.trim() || !email.trim() || !password.trim()) {
      Alert.alert('Ошибка', 'Заполните все поля');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Ошибка', 'Пароль должен быть не менее 6 символов');
      return;
    }
    try {
      setLoading(true);
      await register(name, email, password);
      Alert.alert('✅ Успех', 'Аккаунт создан');
      try {
        if (navigation.canGoBack()) {
          navigation.goBack();
        }
      } catch (navErr) {
        console.log('Navigation back skipped:', navErr.message);
      }
    } catch (err) {
      console.error('Register error:', err);
      Alert.alert('Ошибка регистрации', err.message || 'Не удалось создать аккаунт');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.canGoBack() ? navigation.goBack() : navigation.navigate('FestivalsList')}>
        <Text style={styles.backText}>← Назад</Text>
      </TouchableOpacity>

      <Text style={styles.header}>Регистрация</Text>

      <View style={styles.group}>
        <Text style={styles.label}>Имя</Text>
        <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Иван" placeholderTextColor={COLORS.placeholder} />
      </View>

      <View style={styles.group}>
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          placeholder="email@example.com"
          keyboardType="email-address"
          autoCapitalize="none"
          placeholderTextColor={COLORS.placeholder}
        />
      </View>

      <View style={styles.group}>
        <Text style={styles.label}>Пароль</Text>
        <TextInput
          style={styles.input}
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          secureTextEntry
          placeholderTextColor={COLORS.placeholder}
        />
      </View>

      <TouchableOpacity style={styles.btnPrimary} onPress={handleRegister} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnPrimaryText}>Создать аккаунт</Text>}
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text style={styles.link}>Уже есть аккаунт? Войти</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: COLORS.background, justifyContent: 'center' },
  backBtn: { position: 'absolute', top: 50, left: 16 },
  backText: { fontSize: 15, color: COLORS.text, fontWeight: '500' },
  header: { fontSize: 28, fontWeight: '500', marginBottom: 24, color: COLORS.primary, marginTop: 40 },
  group: { marginBottom: 16 },
  label: { fontSize: 14, color: COLORS.text, marginBottom: 5, fontWeight: '500' },
  input: {
    borderWidth: 1.5,
    borderColor: COLORS.border,
    borderRadius: 12,
    padding: 12,
    fontSize: 15,
    backgroundColor: COLORS.white,
    color: '#333',
  },
  btnPrimary: {
    backgroundColor: COLORS.primary,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  btnPrimaryText: { color: '#fff', fontSize: 16, fontWeight: '500' },
  link: { textAlign: 'center', marginTop: 16, fontSize: 15, color: COLORS.primary, fontWeight: '500' },
});
