import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { COLORS } from '../theme/colors';
import { LinearGradient } from 'expo-linear-gradient';

export default function ProfileScreen({ navigation }) {
  const { user, logout, loading } = useAuth();

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Загрузка профиля...</Text>
      </View>
    );
  }

  if (!user) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.emptyTitle}>Войдите в аккаунт</Text>
        <Text style={styles.emptyText}>Чтобы видеть свой профиль и заявки</Text>
        <TouchableOpacity style={styles.btnPrimary} onPress={() => navigation.navigate('Login')}>
          <Text style={styles.btnPrimaryText}>Войти</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Register')}>
          <Text style={styles.link}>Нет аккаунта? Зарегистрироваться</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const name = user?.full_name || user?.name || user?.display_name || 'Пользователь';
  const email = user?.email || '';
  const city = user?.city || '';
  const position = user?.contact_position || '';
  const initial = (name || email || 'А').charAt(0).toUpperCase();

  const menuItems = [
    { label: 'Мои заявки', onPress: () => navigation.navigate('Applications') },
    { label: 'Уведомления', onPress: () => navigation.navigate('Notifications') },
    { label: 'Настройки', onPress: () => {} },
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Личный кабинет</Text>

      <View style={styles.profileHeader}>
        <LinearGradient
          colors={[COLORS.primary, COLORS.primaryLight]}
          style={styles.avatar}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <Text style={styles.avatarText}>{initial}</Text>
        </LinearGradient>
        <View style={styles.nameBlock}>
          <Text style={styles.name}>{name}</Text>
          {email ? <Text style={styles.email}>{email}</Text> : null}
          {position ? <Text style={styles.position}>{position}</Text> : null}
          {city ? <Text style={styles.city}>📍 {city}</Text> : null}
        </View>
      </View>

      {menuItems.map((item, index) => (
        <TouchableOpacity key={index} style={styles.menuItem} onPress={item.onPress}>
          <Text style={styles.menuText}>{item.label}</Text>
          <Text style={styles.arrow}>→</Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity style={[styles.menuItem, styles.logout]} onPress={logout}>
        <Text style={[styles.menuText, styles.logoutText]}>Выйти</Text>
        <Text style={[styles.arrow, styles.logoutText]}>→</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: COLORS.background },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 20 },
  header: { fontSize: 28, fontWeight: '500', marginBottom: 20, marginTop: 8, color: COLORS.primary },
  profileHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 24 },
  avatar: { width: 56, height: 56, borderRadius: 28, justifyContent: 'center', alignItems: 'center', elevation: 4, marginRight: 14 },
  avatarText: { fontSize: 22, fontWeight: '500', color: '#fff' },
  nameBlock: { flex: 1 },
  name: { fontSize: 18, fontWeight: '500', color: COLORS.primary },
  email: { fontSize: 14, color: COLORS.text, marginTop: 2 },
  position: { fontSize: 13, color: COLORS.placeholder, marginTop: 2 },
  city: { fontSize: 13, color: COLORS.placeholder, marginTop: 2 },
  menuItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: COLORS.pale },
  menuText: { fontSize: 16, color: COLORS.primary },
  arrow: { fontSize: 16, color: COLORS.placeholder },
  logout: { marginTop: 8 },
  logoutText: { color: COLORS.danger },
  loadingText: { marginTop: 16, fontSize: 15, color: COLORS.text },
  emptyTitle: { fontSize: 18, fontWeight: '500', marginBottom: 6, color: COLORS.primary },
  emptyText: { fontSize: 15, color: COLORS.text, marginBottom: 12, textAlign: 'center' },
  btnPrimary: { backgroundColor: COLORS.primary, paddingHorizontal: 32, paddingVertical: 14, borderRadius: 12, marginTop: 8, elevation: 4 },
  btnPrimaryText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  link: { textAlign: 'center', marginTop: 16, fontSize: 15, color: COLORS.primary, fontWeight: '500' },
});
