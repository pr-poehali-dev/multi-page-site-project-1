import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, RefreshControl, StyleSheet, ActivityIndicator } from 'react-native';
import FestivalCard from '../components/FestivalCard';
import { fetchFestivals } from '../api/festivals';
import { COLORS } from '../theme/colors';

function isNotArchived(contest) {
  const status = String(contest.status || '').toLowerCase();
  if (!status) return true;
  const archivedStatuses = ['archived', 'closed', 'finished', 'завершён', 'архив', 'completed', 'past', 'inactive'];
  return !archivedStatuses.includes(status);
}

export default function FestivalsScreen({ navigation }) {
  const [festivals, setFestivals] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const loadFestivals = async () => {
    try {
      setError(null);
      const data = await fetchFestivals();
      console.log('🎭 Loaded contests count:', data.length);
      const visibleList = data.filter(isNotArchived);
      console.log('🎭 Visible contests count:', visibleList.length);
      setFestivals(visibleList);
      setFiltered(visibleList);
    } catch (err) {
      setError('Не удалось загрузить фестивали');
      console.error(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { loadFestivals(); }, []);

  useEffect(() => {
    const q = search.toLowerCase();
    setFiltered(
      festivals.filter(
        (f) =>
          (f.title || '').toLowerCase().includes(q) ||
          (f.location || '').toLowerCase().includes(q) ||
          (f.city || '').toLowerCase().includes(q)
      )
    );
  }, [search, festivals]);

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Фестивали</Text>
      <TextInput
        style={styles.search}
        placeholder="Поиск по названию, городу..."
        value={search}
        onChangeText={setSearch}
        placeholderTextColor={COLORS.placeholder}
      />
      {error ? (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      ) : null}
      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.id || item._id || Math.random())}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadFestivals(); }} tintColor={COLORS.primary} />
        }
        renderItem={({ item }) => (
          <FestivalCard
            festival={item}
            onPress={() => navigation.navigate('FestivalDetail', { festival: item })}
          />
        )}
        ListEmptyComponent={
          <View style={styles.emptyBox}>
            <Text style={styles.empty}>Нет доступных конкурсов</Text>
          </View>
        }
        contentContainerStyle={{ paddingBottom: 20 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: COLORS.background },
  center: { justifyContent: 'center', alignItems: 'center' },
  header: { fontSize: 28, fontWeight: '600', marginBottom: 16, marginTop: 8, color: COLORS.primary },
  search: {
    borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 12, padding: 12, fontSize: 15,
    marginBottom: 14, backgroundColor: COLORS.white, color: '#333',
  },
  errorBox: { backgroundColor: '#ffebee', padding: 12, borderRadius: 8, marginBottom: 12 },
  errorText: { color: COLORS.danger, fontSize: 14 },
  emptyBox: { alignItems: 'center', marginTop: 60, paddingHorizontal: 20 },
  empty: { textAlign: 'center', color: COLORS.placeholder, fontSize: 16, fontWeight: '500' },
});
