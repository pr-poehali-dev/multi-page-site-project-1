import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image, Linking, Alert } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { COLORS } from '../theme/colors';

export default function FestivalDetailScreen({ navigation, route }) {
  const { festival } = route.params;
  const { user } = useAuth();

  const imageUrl = festival.poster_url || festival.logo_url || festival.image || '';
  const title = festival.title || festival.name || 'Без названия';
  const city = festival.location || festival.city || '';
  const dateStr = festival.event_date || festival.date || '';
  const type = festival.type || festival.category || '';
  const description = festival.description || festival.desc || festival.about || '';
  const deadline = festival.end_date || '';
  const fee = festival.fee || festival.price || '';

  const applyLink = festival.application_form_url || festival.application_link || festival.apply_url || '';
  const rulesLink = festival.pdf_url || festival.rules_url || festival.regulation_url || '';
  const isExternal = festival.application_type === 'external';
  const isInternal = festival.application_type === 'internal';

  const openLink = async (url, label) => {
    if (!url) {
      Alert.alert('Ссылка недоступна', `${label} для этого конкурса пока не опубликовано.`);
      return;
    }
    const supported = await Linking.canOpenURL(url);
    if (supported) {
      await Linking.openURL(url);
    } else {
      Alert.alert('Ошибка', `Не удалось открыть ссылку`);
    }
  };

  const handleApply = () => {
    if (isExternal && applyLink) {
      openLink(applyLink, 'Форма заявки');
      return;
    }
    if (isInternal) {
      if (!user) {
        navigation.navigate('Login');
      } else {
        navigation.navigate('Apply', { festival });
      }
      return;
    }
    if (applyLink) {
      openLink(applyLink, 'Форма заявки');
    } else if (!user) {
      navigation.navigate('Login');
    } else {
      navigation.navigate('Apply', { festival });
    }
  };

  const handleRules = () => {
    openLink(rulesLink, 'Положение');
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>← Назад</Text>
      </TouchableOpacity>

      <View style={styles.imageContainer}>
        {imageUrl ? (
          <Image source={{ uri: imageUrl }} style={styles.image} resizeMode="cover" />
        ) : (
          <View style={styles.imagePlaceholder}>
            <Text style={styles.placeholderEmoji}>🎭</Text>
          </View>
        )}
        {type ? (
          <View style={styles.typeBadge}>
            <Text style={styles.typeBadgeText}>{type}</Text>
          </View>
        ) : null}
      </View>

      <View style={styles.content}>
        <Text style={styles.title}>{title}</Text>

        <View style={styles.metaBlock}>
          {dateStr ? (
            <View style={styles.metaRow}>
              <Text style={styles.metaIcon}>📅</Text>
              <Text style={styles.metaLabel}>Даты:</Text>
              <Text style={styles.metaValue}>{dateStr}</Text>
            </View>
          ) : null}
          {city ? (
            <View style={styles.metaRow}>
              <Text style={styles.metaIcon}>📍</Text>
              <Text style={styles.metaLabel}>Город:</Text>
              <Text style={styles.metaValue}>{city}</Text>
            </View>
          ) : null}
          {deadline ? (
            <View style={styles.metaRow}>
              <Text style={styles.metaIcon}>⏰</Text>
              <Text style={styles.metaLabel}>Дедлайн:</Text>
              <Text style={styles.metaValue}>{deadline}</Text>
            </View>
          ) : null}
          {fee ? (
            <View style={styles.metaRow}>
              <Text style={styles.metaIcon}>💰</Text>
              <Text style={styles.metaLabel}>Взнос:</Text>
              <Text style={styles.metaValue}>{fee}</Text>
            </View>
          ) : null}
        </View>

        {description ? (
          <View style={styles.descBlock}>
            <Text style={styles.descTitle}>О конкурсе</Text>
            <Text style={styles.description}>{description}</Text>
          </View>
        ) : null}

        <TouchableOpacity style={styles.btnPrimary} onPress={handleApply}>
          <Text style={styles.btnPrimaryText}>
            {isExternal && applyLink ? '🌐 Подать заявку на сайте' : '📝 Подать заявку'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.btnSecondary, !rulesLink && styles.btnDisabled]}
          onPress={handleRules}
          disabled={!rulesLink}
        >
          <Text style={[styles.btnSecondaryText, !rulesLink && styles.btnDisabledText]}>
            📋 Положение
          </Text>
        </TouchableOpacity>

        {!applyLink && !rulesLink && !isInternal ? (
          <Text style={styles.hint}>Ссылки на форму и положение скоро появятся</Text>
        ) : null}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  backBtn: { paddingHorizontal: 16, paddingTop: 16, paddingBottom: 8 },
  backText: { fontSize: 15, color: COLORS.text, fontWeight: '500' },
  imageContainer: { width: '100%', height: 220, position: 'relative', backgroundColor: COLORS.pale },
  image: { width: '100%', height: '100%' },
  imagePlaceholder: { width: '100%', height: '100%', backgroundColor: COLORS.pale, justifyContent: 'center', alignItems: 'center' },
  placeholderEmoji: { fontSize: 64 },
  typeBadge: { position: 'absolute', top: 16, left: 16, backgroundColor: 'rgba(75, 0, 130, 0.85)', paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20 },
  typeBadgeText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  content: { padding: 16, paddingTop: 20 },
  title: { fontSize: 24, fontWeight: '600', color: COLORS.primary, marginBottom: 16, lineHeight: 30 },
  metaBlock: { backgroundColor: COLORS.white, borderRadius: 12, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: COLORS.pale },
  metaRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6 },
  metaIcon: { fontSize: 15, width: 22, marginRight: 6 },
  metaLabel: { fontSize: 14, color: COLORS.text, fontWeight: '500', width: 70 },
  metaValue: { fontSize: 14, color: '#333', flex: 1 },
  descBlock: { marginBottom: 20 },
  descTitle: { fontSize: 18, fontWeight: '600', color: COLORS.primary, marginBottom: 10 },
  description: { fontSize: 15, lineHeight: 23, color: '#444' },
  btnPrimary: { backgroundColor: COLORS.primary, padding: 16, borderRadius: 12, alignItems: 'center', marginBottom: 10, shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 4 },
  btnPrimaryText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  btnSecondary: { backgroundColor: COLORS.white, padding: 16, borderRadius: 12, alignItems: 'center', borderWidth: 1.5, borderColor: COLORS.border, marginBottom: 10 },
  btnSecondaryText: { color: COLORS.primary, fontSize: 16, fontWeight: '600' },
  btnDisabled: { borderColor: '#E0E0E0', backgroundColor: '#F5F5F5' },
  btnDisabledText: { color: '#BDBDBD' },
  hint: { textAlign: 'center', fontSize: 13, color: COLORS.placeholder, marginTop: 8 },
});
