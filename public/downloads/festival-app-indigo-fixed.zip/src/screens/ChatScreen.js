import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { fetchChatMessages, sendChatMessage, markChatRead } from '../api/festivals';
import { COLORS } from '../theme/colors';

function formatTime(raw) {
  if (!raw) return '';
  try {
    const d = new Date(raw);
    const time = d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    const date = d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
    return `${time} · ${date}`;
  } catch {
    return '';
  }
}

function MessageBubble({ item }) {
  const isUser = item.sender === 'user';
  return (
    <View style={[styles.bubbleRow, isUser ? styles.bubbleRowUser : styles.bubbleRowAdmin]}>
      <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleAdmin]}>
        <Text style={[styles.bubbleText, isUser && styles.bubbleTextUser]}>{item.message}</Text>
        <Text style={[styles.bubbleTime, isUser && styles.bubbleTimeUser]}>{formatTime(item.created_at)}</Text>
      </View>
    </View>
  );
}

export default function ChatScreen() {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);
  const listRef = useRef(null);
  const intervalRef = useRef(null);

  const load = useCallback(async (silent) => {
    try {
      if (!silent) setError(null);
      const list = await fetchChatMessages();
      setMessages(list);
      markChatRead().catch(() => {});
    } catch (e) {
      if (!silent) setError(e.message || 'Не удалось загрузить чат');
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    load(false);
    intervalRef.current = setInterval(() => load(true), 8000);
    return () => clearInterval(intervalRef.current);
  }, [user, load]);

  const handleSend = async () => {
    const value = text.trim();
    if (!value || sending) return;
    setSending(true);
    setText('');
    try {
      const message = await sendChatMessage(value);
      if (message) {
        setMessages(prev => [...prev, message]);
      } else {
        load(true);
      }
    } catch (e) {
      setText(value);
    } finally {
      setSending(false);
    }
  };

  if (!user) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.emptyTitle}>Войдите в аккаунт</Text>
        <Text style={styles.emptyText}>Чтобы написать организаторам</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Загрузка чата...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.emptyTitle}>Ошибка</Text>
        <Text style={styles.emptyText}>{error}</Text>
        <TouchableOpacity style={styles.btnPrimary} onPress={() => { setLoading(true); load(false); }}>
          <Text style={styles.btnPrimaryText}>Повторить</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={90}
    >
      <Text style={styles.header}>Чат с организаторами</Text>
      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={item => String(item.id)}
        renderItem={({ item }) => <MessageBubble item={item} />}
        contentContainerStyle={messages.length === 0 ? styles.emptyList : styles.list}
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
        ListEmptyComponent={
          <View style={styles.center}>
            <Text style={styles.emptyTitle}>Нет сообщений</Text>
            <Text style={styles.emptyText}>Напишите нам, если есть вопросы!</Text>
          </View>
        }
      />
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          value={text}
          onChangeText={setText}
          placeholder="Написать сообщение..."
          placeholderTextColor={COLORS.placeholder}
          multiline
          editable={!sending}
        />
        <TouchableOpacity
          style={[styles.sendBtn, (!text.trim() || sending) && styles.sendBtnDisabled]}
          onPress={handleSend}
          disabled={!text.trim() || sending}
        >
          {sending ? <ActivityIndicator size="small" color="#fff" /> : <Text style={styles.sendBtnText}>➤</Text>}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, paddingHorizontal: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 20, paddingTop: 60 },
  header: { fontSize: 28, fontWeight: '500', marginBottom: 12, marginTop: 8, color: COLORS.primary },
  list: { paddingBottom: 12 },
  emptyList: { flexGrow: 1 },
  bubbleRow: { flexDirection: 'row', marginBottom: 10 },
  bubbleRowUser: { justifyContent: 'flex-end' },
  bubbleRowAdmin: { justifyContent: 'flex-start' },
  bubble: { maxWidth: '78%', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 18 },
  bubbleUser: { backgroundColor: COLORS.primary, borderBottomRightRadius: 4 },
  bubbleAdmin: { backgroundColor: COLORS.pale, borderBottomLeftRadius: 4 },
  bubbleText: { fontSize: 15, color: COLORS.text, lineHeight: 20 },
  bubbleTextUser: { color: '#fff' },
  bubbleTime: { fontSize: 11, color: COLORS.placeholder, marginTop: 4 },
  bubbleTimeUser: { color: 'rgba(255,255,255,0.7)' },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  input: {
    flex: 1,
    backgroundColor: COLORS.cardBg,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 15,
    color: COLORS.text,
    maxHeight: 100,
    marginRight: 10,
  },
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendBtnDisabled: { opacity: 0.4 },
  sendBtnText: { color: '#fff', fontSize: 18 },
  loadingText: { marginTop: 16, fontSize: 15, color: COLORS.text },
  emptyTitle: { fontSize: 18, fontWeight: '500', marginBottom: 6, color: COLORS.primary, textAlign: 'center' },
  emptyText: { fontSize: 15, color: COLORS.text, marginBottom: 12, textAlign: 'center' },
  btnPrimary: { backgroundColor: COLORS.primary, paddingHorizontal: 32, paddingVertical: 14, borderRadius: 12, marginTop: 8 },
  btnPrimaryText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
