import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Linking, Alert, TextInput, ActivityIndicator, Switch, Modal,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { COLORS } from '../theme/colors';
import { submitInternalApplication, uploadToYandexDisk, fetchContestForm } from '../api/festivals';
import * as DocumentPicker from 'expo-document-picker';
import { readAsStringAsync } from 'expo-file-system';

export default function ApplyScreen({ navigation, route }) {
  const { festival } = route.params;
  const { user } = useAuth();

  const applyLink = festival.application_form_url || festival.apply_url || festival.form_url ||
                    festival.registration_link || festival.external_form || '';
  const isExternal = festival.application_type === 'external';

  // ==================== EXTERNAL ====================
  if (isExternal) {
    const openExternalForm = async () => {
      if (!applyLink) {
        Alert.alert('Ошибка', 'Ссылка на форму заявки недоступна');
        return;
      }
      const supported = await Linking.canOpenURL(applyLink);
      if (supported) {
        await Linking.openURL(applyLink);
      } else {
        Alert.alert('Ошибка', 'Не удалось открыть ссылку');
      }
    };

    return (
      <ScrollView style={styles.container}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>← Назад к фестивалю</Text>
        </TouchableOpacity>

        <Text style={styles.header}>Заявка на участие</Text>
        <Text style={styles.festivalName}>{festival.title || festival.name}</Text>

        <View style={styles.infoBox}>
          <Text style={styles.infoText}>
            Для подачи заявки на этот конкурс используется официальная форма на сайте ИНДИГО.
          </Text>
        </View>

        {applyLink ? (
          <TouchableOpacity style={styles.btnPrimary} onPress={openExternalForm}>
            <Text style={styles.btnPrimaryText}>🌐 Открыть форму на сайте</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.noLinkBox}>
            <Text style={styles.noLinkText}>Ссылка на форму пока не опубликована</Text>
            <Text style={styles.noLinkSub}>Проверьте позже или свяжитесь с организаторами</Text>
          </View>
        )}

        <TouchableOpacity style={styles.btnSecondary} onPress={() => navigation.goBack()}>
          <Text style={styles.btnSecondaryText}>← Вернуться к фестивалю</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // ==================== INTERNAL ====================
  const [loadingForm, setLoadingForm] = useState(true);
  const [formError, setFormError] = useState(null);
  const [formFields, setFormFields] = useState([]);
  const [nominations, setNominations] = useState([]);
  const [formValues, setFormValues] = useState({});
  const [baseValues, setBaseValues] = useState({
    fullName: user?.full_name || user?.name || user?.participant?.full_name || '',
    email: user?.email || user?.participant?.email || '',
    phone: user?.phone || user?.participant?.phone || '',
    city: user?.city || user?.participant?.city || '',
    nominationId: '',
  });
  const [selectModal, setSelectModal] = useState({ visible: false, field: null, options: [] });
  const [uploadingField, setUploadingField] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    // Логируем все поля конкурса — ищем полное название
    console.log('📋 Festival fields:', JSON.stringify(
      Object.keys(festival).reduce((acc, k) => {
        acc[k] = String(festival[k]).substring(0, 100);
        return acc;
      }, {})
    , null, 2));
    loadForm();
  }, []);

  const loadForm = async () => {
    try {
      setLoadingForm(true);
      setFormError(null);
      const contestId = festival.id || festival._id;
      const data = await fetchContestForm(contestId);
      console.log('📋 Form data:', JSON.stringify(data, null, 2));

      const fields = (data.fields || []).sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
      setFormFields(fields);
      setNominations(data.nominations || []);

      // Init form values
      const initial = {};
      fields.forEach(f => {
        if (f.field_type === 'checkbox') {
          initial[f.field_name] = 'false';
        } else {
          initial[f.field_name] = '';
        }
      });
      setFormValues(initial);
    } catch (err) {
      console.error('❌ Failed to load form:', err);
      setFormError(err.message || 'Не удалось загрузить форму заявки');
    } finally {
      setLoadingForm(false);
    }
  };

  const openSelect = (field) => {
    const options = (field.options || '').split(',').map(s => s.trim()).filter(Boolean);
    setSelectModal({ visible: true, field, options });
  };

  const selectOption = (option) => {
    if (selectModal.field) {
      setFormValues(prev => ({ ...prev, [selectModal.field.field_name]: option }));
    }
    setSelectModal({ visible: false, field: null, options: [] });
  };

  const pickFile = async (field) => {
    try {
      const mimeType = field.field_type === 'audio' ? 'audio/*' : '*/*';
      const result = await DocumentPicker.getDocumentAsync({
        type: mimeType,
        copyToCacheDirectory: true,
      });
      if (!result.canceled && result.assets && result.assets.length > 0) {
        const file = result.assets[0];
        const maxSize = field.field_type === 'audio' ? 50 * 1024 * 1024 : 15 * 1024 * 1024;
        if (file.size && file.size > maxSize) {
          Alert.alert('Файл слишком большой', `Максимум ${field.field_type === 'audio' ? '50' : '15'} МБ`);
          return;
        }
        await uploadFileForField(field, file);
      }
    } catch (err) {
      Alert.alert('Ошибка', 'Не удалось выбрать файл');
    }
  };

  const uploadFileForField = async (field, file) => {
    try {
      setUploadingField(field.field_name);
      console.log('📁 Uploading to Yandex Disk:', file.name);
      // Формируем contestTitle как на сайте: "Название, Город, Дата"
      const parts = [];
      if (festival.title || festival.name) parts.push(festival.title || festival.name);
      if (festival.city || festival.location) parts.push(festival.city || festival.location);
      if (festival.date || festival.event_date) parts.push(festival.date || festival.event_date);
      const contestTitle = parts.join(', ');
      console.log('📋 contestTitle:', contestTitle);

      const url = await uploadToYandexDisk(
        {
          uri: file.uri,
          name: file.name,
          mimeType: file.mimeType || (field.field_type === 'audio' ? 'audio/mpeg' : 'application/octet-stream'),
        },
        contestTitle
      );
      console.log('✅ Yandex Disk URL:', url);
      setFormValues(prev => ({ ...prev, [field.field_name]: url }));
      Alert.alert('✅ Файл загружен', file.name);
    } catch (err) {
      console.error('❌ Upload error:', err);
      Alert.alert('Ошибка загрузки', err.message || 'Не удалось загрузить файл на Яндекс.Диск');
    } finally {
      setUploadingField(null);
    }
  };

  const validate = () => {
    const missing = [];
    if (!baseValues.fullName.trim()) missing.push('ФИО');
    if (!baseValues.email.trim()) missing.push('Email');
    if (!baseValues.phone.trim()) missing.push('Телефон');
    if (!baseValues.city.trim()) missing.push('Город');

    for (const field of formFields) {
      if (field.is_required) {
        const val = formValues[field.field_name];
        if (!val || val === '' || val === 'false') {
          missing.push(field.field_label);
        }
      }
    }

    if (missing.length > 0) {
      Alert.alert('Заполните обязательные поля', missing.join('\n'));
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validate()) return;

    try {
      setSubmitting(true);
      const customFields = {};
      for (const field of formFields) {
        const val = formValues[field.field_name];
        if (val !== undefined && val !== '' && val !== null) {
          customFields[field.field_name] = val;
        }
      }

      const payload = {
        fullName: baseValues.fullName.trim() || user?.full_name || user?.name || '',
        email: baseValues.email.trim() || user?.email || '',
        phone: baseValues.phone.trim() || user?.phone || '',
        city: baseValues.city.trim() || user?.city || '',
        contestId: festival.id || festival._id,
        customFields,
      };

      if (baseValues.nominationId) {
        payload.nominationId = parseInt(baseValues.nominationId, 10) || baseValues.nominationId;
      }

      console.log('📤 Submitting payload:', JSON.stringify(payload, null, 2));
      const result = await submitInternalApplication(payload);
      Alert.alert(
        '✅ Заявка отправлена',
        `Номер заявки: ${result.applicationId || result.id || '—'}\nСтатус: ${result.status || 'на рассмотрении'}`,
        [{ text: 'OK', onPress: () => navigation.goBack() }]
      );
    } catch (err) {
      Alert.alert('Ошибка отправки', err.message || 'Не удалось отправить заявку');
    } finally {
      setSubmitting(false);
    }
  };

  const renderField = (field) => {
    const value = formValues[field.field_name] || '';
    const required = field.is_required;
    const label = `${field.field_label}${required ? ' *' : ''}`;

    switch (field.field_type) {
      case 'text':
      case 'number':
      case 'email':
      case 'tel':
      case 'date': {
        let keyboard = 'default';
        if (field.field_type === 'number') keyboard = 'numeric';
        if (field.field_type === 'email') keyboard = 'email-address';
        if (field.field_type === 'tel') keyboard = 'phone-pad';
        return (
          <View key={field.field_name} style={styles.fieldBox}>
            <Text style={styles.label}>{label}</Text>
            <TextInput
              style={styles.input}
              value={value}
              onChangeText={text => setFormValues(prev => ({ ...prev, [field.field_name]: text }))}
              placeholder={field.field_label}
              keyboardType={keyboard}
              placeholderTextColor={COLORS.placeholder}
            />
          </View>
        );
      }

      case 'textarea':
        return (
          <View key={field.field_name} style={styles.fieldBox}>
            <Text style={styles.label}>{label}</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={value}
              onChangeText={text => setFormValues(prev => ({ ...prev, [field.field_name]: text }))}
              placeholder={field.field_label}
              multiline
              numberOfLines={4}
              placeholderTextColor={COLORS.placeholder}
            />
          </View>
        );

      case 'select':
        return (
          <View key={field.field_name} style={styles.fieldBox}>
            <Text style={styles.label}>{label}</Text>
            <TouchableOpacity
              style={styles.selectBox}
              onPress={() => openSelect(field)}
            >
              <Text style={value ? styles.selectValue : styles.selectPlaceholder}>
                {value || `Выберите ${field.field_label}`}
              </Text>
              <Text style={styles.selectArrow}>▼</Text>
            </TouchableOpacity>
          </View>
        );

      case 'checkbox':
        return (
          <View key={field.field_name} style={styles.checkboxRow}>
            <Switch
              value={value === 'true'}
              onValueChange={val => setFormValues(prev => ({ ...prev, [field.field_name]: val ? 'true' : 'false' }))}
              trackColor={{ false: '#ccc', true: COLORS.primary }}
              thumbColor="#fff"
            />
            <Text style={styles.checkboxLabel}>{label}</Text>
          </View>
        );

      case 'file':
      case 'audio': {
        const isUploading = uploadingField === field.field_name;
        const hasFile = !!value;
        return (
          <View key={field.field_name} style={styles.fieldBox}>
            <Text style={styles.label}>{label}</Text>
            {hasFile ? (
              <View style={styles.filePreview}>
                <Text style={styles.filePreviewText} numberOfLines={1}>
                  {field.field_type === 'audio' ? '🎵' : '📎'} {value.split('/').pop() || 'Файл загружен'}
                </Text>
                <TouchableOpacity onPress={() => setFormValues(prev => ({ ...prev, [field.field_name]: '' }))}>
                  <Text style={styles.fileRemove}>✕</Text>
                </TouchableOpacity>
              </View>
            ) : null}
            <TouchableOpacity
              style={[styles.btnAttach, isUploading && styles.btnDisabled]}
              onPress={() => pickFile(field)}
              disabled={isUploading}
            >
              {isUploading ? (
                <ActivityIndicator color={COLORS.primary} size="small" />
              ) : (
                <Text style={styles.btnAttachText}>
                  {field.field_type === 'audio' ? '🎵 Прикрепить аудио' : '📎 Прикрепить файл'} (до {field.field_type === 'audio' ? '50' : '15'} МБ)
                </Text>
              )}
            </TouchableOpacity>
          </View>
        );
      }

      default:
        return (
          <View key={field.field_name} style={styles.fieldBox}>
            <Text style={styles.label}>{label}</Text>
            <TextInput
              style={styles.input}
              value={value}
              onChangeText={text => setFormValues(prev => ({ ...prev, [field.field_name]: text }))}
              placeholder={field.field_label}
              placeholderTextColor={COLORS.placeholder}
            />
          </View>
        );
    }
  };

  if (loadingForm) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Загрузка формы заявки...</Text>
      </View>
    );
  }

  if (formError) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.errorText}>⚠️ {formError}</Text>
        <TouchableOpacity style={styles.btnSecondary} onPress={loadForm}>
          <Text style={styles.btnSecondaryText}>Повторить</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>← Назад</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} keyboardShouldPersistTaps="handled">
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>← Назад к фестивалю</Text>
      </TouchableOpacity>

      <Text style={styles.header}>Подать заявку</Text>
      <Text style={styles.festivalName}>{festival.title || festival.name}</Text>

      <View style={styles.formBox}>
        {/* Базовые поля — скрыты, данные берутся из профиля */}
        {false && (
          <>
            <Text style={styles.sectionTitle}>Контактные данные</Text>

            <Text style={styles.label}>ФИО *</Text>
            <TextInput
              style={styles.input}
              value={baseValues.fullName}
              onChangeText={text => setBaseValues(prev => ({ ...prev, fullName: text }))}
              placeholder="Иванов Иван Иванович"
              placeholderTextColor={COLORS.placeholder}
            />

            <Text style={styles.label}>Email *</Text>
            <TextInput
              style={styles.input}
              value={baseValues.email}
              onChangeText={text => setBaseValues(prev => ({ ...prev, email: text }))}
              placeholder="email@example.com"
              keyboardType="email-address"
              autoCapitalize="none"
              placeholderTextColor={COLORS.placeholder}
            />

            <Text style={styles.label}>Телефон *</Text>
            <TextInput
              style={styles.input}
              value={baseValues.phone}
              onChangeText={text => setBaseValues(prev => ({ ...prev, phone: text }))}
              placeholder="+7 (999) 000-00-00"
              keyboardType="phone-pad"
              placeholderTextColor={COLORS.placeholder}
            />

            <Text style={styles.label}>Город *</Text>
            <TextInput
              style={styles.input}
              value={baseValues.city}
              onChangeText={text => setBaseValues(prev => ({ ...prev, city: text }))}
              placeholder="Москва"
              placeholderTextColor={COLORS.placeholder}
            />
          </>
        )}

        {/* Номинации — скрыты */}
        {false && nominations.length > 0 && (
          <>
            <Text style={styles.sectionTitle}>Номинация</Text>
            <TouchableOpacity
              style={styles.selectBox}
              onPress={() => {
                const opts = nominations.map(n => n.name);
                setSelectModal({
                  visible: true,
                  field: { field_name: '__nomination', field_label: 'Номинация' },
                  options: opts,
                  isNomination: true,
                });
              }}
            >
              <Text style={baseValues.nominationId ? styles.selectValue : styles.selectPlaceholder}>
                {baseValues.nominationId
                  ? nominations.find(n => n.id === parseInt(baseValues.nominationId))?.name || 'Выбрана'
                  : 'Выберите номинацию'}
              </Text>
              <Text style={styles.selectArrow}>▼</Text>
            </TouchableOpacity>
          </>
        )}

        {/* Динамические поля формы */}
        {formFields.length > 0 && (
          <>
            <Text style={styles.sectionTitle}>Дополнительная информация</Text>
            {formFields.map(renderField)}
          </>
        )}

        {/* Кнопка отправки */}
        <TouchableOpacity
          style={[styles.btnPrimary, submitting && styles.btnDisabled]}
          onPress={handleSubmit}
          disabled={submitting}
        >
          {submitting ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.btnPrimaryText}>📤 Отправить заявку</Text>
          )}
        </TouchableOpacity>
      </View>

      {/* Modal для select */}
      <Modal
        visible={selectModal.visible}
        transparent
        animationType="slide"
        onRequestClose={() => setSelectModal({ visible: false, field: null, options: [] })}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {selectModal.field?.field_label || 'Выберите'}
            </Text>
            <ScrollView style={styles.modalList}>
              {selectModal.options?.map((opt, idx) => (
                <TouchableOpacity
                  key={idx}
                  style={styles.modalItem}
                  onPress={() => {
                    if (selectModal.isNomination) {
                      const nom = nominations.find(n => n.name === opt);
                      setBaseValues(prev => ({ ...prev, nominationId: String(nom?.id || '') }));
                    } else {
                      selectOption(opt);
                    }
                    setSelectModal({ visible: false, field: null, options: [] });
                  }}
                >
                  <Text style={styles.modalItemText}>{opt}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TouchableOpacity
              style={styles.modalClose}
              onPress={() => setSelectModal({ visible: false, field: null, options: [] })}
            >
              <Text style={styles.modalCloseText}>Отмена</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, padding: 16 },
  center: { justifyContent: 'center', alignItems: 'center', paddingTop: 100 },
  backBtn: { marginTop: 8, marginBottom: 12 },
  backText: { fontSize: 15, color: COLORS.text },
  header: { fontSize: 24, fontWeight: '500', marginBottom: 4, color: COLORS.primary },
  festivalName: { fontSize: 15, color: COLORS.text, marginBottom: 20, fontWeight: '500' },
  infoBox: { backgroundColor: COLORS.pale, borderRadius: 12, padding: 14, marginBottom: 20 },
  infoText: { fontSize: 14, color: COLORS.primary, lineHeight: 20 },
  btnPrimary: { backgroundColor: COLORS.primary, padding: 16, borderRadius: 12, alignItems: 'center', marginBottom: 12, marginTop: 8, shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 4 },
  btnPrimaryText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  btnSecondary: { backgroundColor: COLORS.white, padding: 14, borderRadius: 12, alignItems: 'center', borderWidth: 1.5, borderColor: COLORS.border, marginTop: 8 },
  btnSecondaryText: { color: COLORS.primary, fontSize: 16, fontWeight: '500' },
  noLinkBox: { alignItems: 'center', padding: 20, marginBottom: 12 },
  noLinkText: { fontSize: 15, color: COLORS.placeholder, marginBottom: 4 },
  noLinkSub: { fontSize: 13, color: COLORS.placeholder },
  formBox: { backgroundColor: COLORS.white, borderRadius: 12, padding: 16, borderWidth: 1, borderColor: COLORS.pale },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: COLORS.primary, marginTop: 16, marginBottom: 8 },
  label: { fontSize: 14, color: COLORS.text, fontWeight: '500', marginBottom: 6, marginTop: 10 },
  input: { borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 10, padding: 12, fontSize: 15, backgroundColor: COLORS.background, color: '#333' },
  textArea: { height: 80, textAlignVertical: 'top' },
  btnDisabled: { opacity: 0.6 },
  btnAttach: { borderWidth: 1.5, borderColor: COLORS.border, borderStyle: 'dashed', borderRadius: 10, padding: 12, alignItems: 'center', marginTop: 4, marginBottom: 8 },
  btnAttachText: { color: COLORS.primary, fontSize: 14, fontWeight: '500' },
  selectBox: { borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 10, padding: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: COLORS.background },
  selectValue: { fontSize: 15, color: '#333', flex: 1 },
  selectPlaceholder: { fontSize: 15, color: COLORS.placeholder, flex: 1 },
  selectArrow: { fontSize: 12, color: COLORS.placeholder },
  checkboxRow: { flexDirection: 'row', alignItems: 'center', marginTop: 10, marginBottom: 6 },
  checkboxLabel: { fontSize: 14, color: COLORS.text, marginLeft: 10, flex: 1 },
  fieldBox: { marginBottom: 4 },
  filePreview: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: COLORS.pale, borderRadius: 8, padding: 10, marginBottom: 8 },
  filePreviewText: { fontSize: 13, color: '#333', flex: 1, marginRight: 8 },
  fileRemove: { fontSize: 16, color: '#D32F2F', fontWeight: '600' },
  loadingText: { marginTop: 16, fontSize: 15, color: COLORS.text },
  errorText: { fontSize: 15, color: '#D32F2F', marginBottom: 16, textAlign: 'center' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: COLORS.white, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '70%' },
  modalTitle: { fontSize: 18, fontWeight: '600', color: COLORS.primary, marginBottom: 12 },
  modalList: { maxHeight: 300 },
  modalItem: { paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: COLORS.pale },
  modalItemText: { fontSize: 15, color: '#333' },
  modalClose: { marginTop: 12, padding: 14, backgroundColor: COLORS.pale, borderRadius: 10, alignItems: 'center' },
  modalCloseText: { fontSize: 15, color: COLORS.primary, fontWeight: '500' },
});
