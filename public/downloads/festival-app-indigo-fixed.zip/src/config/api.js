// API конфигурация для ИНДИГО
// Каждый раздел имеет свой отдельный URL на functions.poehali.dev

export const API_URLS = {
  // Конкурсы (список, детали)
  contests: 'https://functions.poehali.dev/53be7002-a84e-4d38-9e81-96d7078f25b3',

  // Заявки участников (подача, редактирование)
  applications: 'https://functions.poehali.dev/065d2b6a-5112-4a26-a642-211398843a75',

  // Вход / регистрация участника, чат, личный кабинет
  auth: 'https://functions.poehali.dev/52234468-777f-4edf-ba7a-985257092904',

  // Программа конкурса, номинации
  program: 'https://functions.poehali.dev/9fcbf70c-fd6d-4489-bc77-1e4bcd6f1cb1',

  // Партнёры / новости / отзывы / настройки
  content: 'https://functions.poehali.dev/7b3c1e0e-bd68-4b73-9377-740689560912',

  // Загрузка файлов (документы/фото для заявки)
  fileUpload: 'https://functions.poehali.dev/cfc99bc2-daff-4110-b9e4-c9699841a7d3',
};

export const API_KEY = 'h99NJWtXVBQ59CqsSyxnIOZI-KwMC1ZpwzohKcM-WkA';

// Заголовок для ключа доступа
export const API_KEY_HEADER = 'X-Api-Key';

// Заголовок для токена участника (сессия)
// ВАЖНО: на functions.poehali.dev заголовок 'Authorization' обрезается облачным
// провайдером на пути к серверу — для передачи токена участника нужен 'X-Authorization'
export const AUTH_HEADER = 'X-Authorization';

// ── Яндекс.Диск (загрузка файлов) ──
// Получить/обновить токен: https://yandex.ru/dev/disk/poligon/
// Нужны права: cloud_api:disk.write
export const YANDEX_DISK_TOKEN = 'y0__wgBEL-CtNwCGNuWAyCxqNzMGDCJh7-LCE9LIfk0Kn3O1KXNQ0nLNOV4v0tz';
