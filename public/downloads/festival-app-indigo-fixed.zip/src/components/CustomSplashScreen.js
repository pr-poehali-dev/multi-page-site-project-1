import React from 'react';
import { View, Image, StyleSheet, StatusBar } from 'react-native';

export default function CustomSplashScreen() {
  return (
    <View style={styles.container}>
      <StatusBar hidden={true} />
      <Image
        source={require('../../assets/splash.png')}
        style={styles.image}
        resizeMode="cover"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#1a0a2e',
  },
  image: {
    width: '100%',
    height: '100%',
  },
});
