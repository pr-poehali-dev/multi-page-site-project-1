import React, { useEffect, useState, useRef } from 'react';
import { Text, StatusBar } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { NavigationContainer } from '@react-navigation/native';
import CustomSplashScreen from './src/components/CustomSplashScreen';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { AuthProvider, useAuth } from './src/context/AuthContext';
import { COLORS } from './src/theme/colors';
import { usePushNotificationsListener } from './src/services/notifications';
import { fetchUnreadChatCount } from './src/api/festivals';

import FestivalsScreen from './src/screens/FestivalsScreen';
import FestivalDetailScreen from './src/screens/FestivalDetailScreen';
import ApplyScreen from './src/screens/ApplyScreen';
import ApplicationsScreen from './src/screens/ApplicationsScreen';
import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import NotificationsScreen from './src/screens/NotificationsScreen';
import ChatScreen from './src/screens/ChatScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

SplashScreen.preventAutoHideAsync();

function FestivalsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="FestivalsList" component={FestivalsScreen} />
      <Stack.Screen name="FestivalDetail" component={FestivalDetailScreen} />
      <Stack.Screen name="Apply" component={ApplyScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}

function ApplicationsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ApplicationsList" component={ApplicationsScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}

function ChatStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ChatMain" component={ChatScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}

function ProfileStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ProfileMain" component={ProfileScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
      <Stack.Screen name="Applications" component={ApplicationsScreen} />
      <Stack.Screen name="Notifications" component={NotificationsScreen} />
    </Stack.Navigator>
  );
}

function TabIcon({ emoji, color }) {
  return (
    <Text style={{ fontSize: 22, color: color, textAlign: 'center' }}>
      {emoji}
    </Text>
  );
}

function AppContent() {
  const { loading, user } = useAuth();
  const [appReady, setAppReady] = useState(false);
  const [unreadChat, setUnreadChat] = useState(0);
  const navigationRef = useRef(null);
  // Переход по нажатию на push-уведомление делается через navigationRef,
  // а не через useNavigation() — обработчик уведомлений не является экраном
  // внутри навигатора, поэтому useNavigation() там бросает ошибку.
  usePushNotificationsListener(navigationRef);

  useEffect(() => {
    if (!user) {
      setUnreadChat(0);
      return;
    }
    const checkUnread = async () => {
      try {
        const count = await fetchUnreadChatCount();
        setUnreadChat(count);
      } catch (e) {
        // тихо игнорируем — не критично
      }
    };
    checkUnread();
    const interval = setInterval(checkUnread, 15000);
    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    async function prepare() {
      try {
        // Системная заставка Android не умеет растягивать картинку на весь экран
        // (показывает только маленькую иконку по центру) — поэтому прячем её
        // сразу и вместо неё на время загрузки показываем свой полноэкранный
        // компонент CustomSplashScreen с картинкой во весь экран.
        await SplashScreen.hideAsync();
        await new Promise(resolve => setTimeout(resolve, 2000));
      } catch (e) {
        console.warn(e);
      } finally {
        setAppReady(true);
      }
    }
    prepare();
  }, []);

  if (!appReady || loading) {
    return (
      <>
        <StatusBar hidden={true} />
        <CustomSplashScreen />
      </>
    );
  }

  return (
    <>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      <NavigationContainer ref={navigationRef}>
        <Tab.Navigator
          screenOptions={{
            headerShown: false,
            tabBarActiveTintColor: COLORS.primary,
            tabBarInactiveTintColor: COLORS.navInactive,
            tabBarStyle: {
              borderTopColor: COLORS.pale,
              backgroundColor: COLORS.white,
              height: 64,
              paddingBottom: 8,
            },
          }}
        >
          <Tab.Screen
            name="ФестивалиTab"
            component={FestivalsStack}
            options={{
              tabBarLabel: 'Фестивали',
              tabBarIcon: ({ color }) => <TabIcon emoji="🎭" color={color} />,
            }}
          />
          <Tab.Screen
            name="ЗаявкиTab"
            component={ApplicationsStack}
            options={{
              tabBarLabel: 'Заявки',
              tabBarIcon: ({ color }) => <TabIcon emoji="📝" color={color} />,
            }}
          />
          <Tab.Screen
            name="ЧатTab"
            component={ChatStack}
            options={{
              tabBarLabel: 'Чат',
              tabBarIcon: ({ color }) => <TabIcon emoji="💬" color={color} />,
              tabBarBadge: unreadChat > 0 ? unreadChat : undefined,
            }}
          />
          <Tab.Screen
            name="ПрофильTab"
            component={ProfileStack}
            options={{
              tabBarLabel: 'Профиль',
              tabBarIcon: ({ color }) => <TabIcon emoji="👤" color={color} />,
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
