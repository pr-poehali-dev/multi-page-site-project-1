# Festival App — Индиго-Арт

Мобильное приложение для фестивалей в фирменной цветовой схеме **Индиго**.

## 🎨 Цветовая схема

| Цвет | Hex | Использование |
|------|-----|---------------|
| Primary | `#4B0082` | Заголовки, кнопки, акценты |
| Primary Dark | `#311B92` | Градиенты, тени |
| Primary Light | `#7C4DFF` | Аватар, градиенты |
| Pale | `#EDE7F6` | Фон карточек, разделители |
| Background | `#FAF8FF` | Фон экранов |
| Tag BG | `#E1BEE7` | Фон тегов |
| Tag Text | `#4A148C` | Текст тегов |

## 🚀 Быстрый старт

```bash
npm install
npx expo start
```

## ⚙️ Настройка API

Откройте `src/config/api.js` и укажите `baseURL` вашего API.

## 📦 Сборка

⚠️ Перед сборкой ОБЯЗАТЕЛЬНО пересоздайте `node_modules` и лок-файл,
иначе версии пакетов могут не совпасть с package.json и сборка на EAS упадёт
с ошибкой несовместимости Kotlin/версий Expo SDK:

```bash
rm -rf node_modules package-lock.json
npm install
npx expo-doctor   # должно быть "18/18 checks passed"
```

Затем сборка:

```bash
npx expo install -g eas-cli
eas build --platform android
```

Если `expo-doctor` ругается на несовпадение версий каких-то пакетов —
выполните `npx expo install --check` и подтвердите обновление, это подтянет
версии, совместимые именно с установленным Expo SDK.
